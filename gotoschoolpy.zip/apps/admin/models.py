from django.db import models

class School(models.Model):
    name = models.CharField(max_length=255)
    npsn = models.CharField(max_length=20, unique=True)
    subdomain = models.CharField(max_length=50, unique=True)
    jenjang = models.CharField(
        max_length=10,
        choices=[
            ('SD', 'SD'),
            ('SMP', 'SMP'),
            ('SMA', 'SMA'),
            ('SMK', 'SMK'),
        ]
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.subdomain})"
