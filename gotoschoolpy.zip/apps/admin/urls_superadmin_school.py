from django.urls import path
from apps.admin.views.superadmin import add_school, edit_school, delete_school

urlpatterns = [
    path('add/', add_school, name='add'),
    path('edit/<int:school_id>/', edit_school, name='edit'),
    path('delete/<int:school_id>/', delete_school, name='delete'),
]
