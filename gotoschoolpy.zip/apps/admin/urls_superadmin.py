from django.urls import path, include

urlpatterns = [
    path('', include('apps.admin.urls_superadmin_dashboard')),
    path('school/', include(('apps.admin.urls_superadmin_school', 'superadmin_school'), namespace='superadmin_school')),
]