from django import forms
from apps.admin.models import School

class SchoolForm(forms.ModelForm):
    class Meta:
        model = School
        fields = ['name', 'npsn', 'subdomain', 'jenjang']
        widgets = {
            'jenjang': forms.Select(choices=[
                ('SD', 'SD'), ('SMP', 'SMP'), ('SMA', 'SMA'), ('SMK', 'SMK')
            ])
        }
