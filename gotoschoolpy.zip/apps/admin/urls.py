# Di gotoschoolpy/urls.py
from django.urls import path, include

urlpatterns = [
    # path('superadmin/', include(('apps.admin.urls_superadmin', 'superadmin'), namespace='superadmin')),
    path('superadmin/school/', include(('apps.admin.urls_superadmin_school', 'superadmin_school'), namespace='superadmin_school')),
]
