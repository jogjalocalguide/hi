from django.urls import path
from apps.admin.views import superadmin

urlpatterns = [
    path('', superadmin.dashboard, name='dashboard'),
]
