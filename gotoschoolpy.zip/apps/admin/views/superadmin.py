from django.shortcuts import render, redirect, get_object_or_404
from apps.admin.models import School
from apps.admin.forms.school_form import SchoolForm
from django.contrib import messages

def dashboard(request):
    schools = School.objects.all()
    return render(request, 'admin/superadmin/dashboard.html', {'schools': schools})

def add_school(request):
    if request.method == 'POST':
        form = SchoolForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Sekolah berhasil ditambahkan.')
            return redirect('dashboard')
    else:
        form = SchoolForm()
    return render(request, 'admin/superadmin/add_school.html', {'form': form})

def edit_school(request, school_id):
    school = get_object_or_404(School, id=school_id)
    if request.method == 'POST':
        form = SchoolForm(request.POST, instance=school)
        if form.is_valid():
            form.save()
            messages.success(request, 'Data sekolah berhasil diperbarui.')
            return redirect('dashboard')
    else:
        form = SchoolForm(instance=school)
    return render(request, 'admin/superadmin/edit_school.html', {'form': form, 'school': school})

def delete_school(request, school_id):
    school = get_object_or_404(School, id=school_id)
    school.delete()
    messages.success(request, 'Sekolah berhasil dihapus.')
    return redirect('dashboard')
