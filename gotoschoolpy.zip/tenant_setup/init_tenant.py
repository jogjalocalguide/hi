import sys, os, logging, subprocess

# 🧭 Ambil argumen dari Django
try:
    name, db_name, jenjang = sys.argv[1], sys.argv[2], sys.argv[3]
except IndexError:
    print("❌ Argumen tidak lengkap: name, db_name, jenjang")
    sys.exit(1)

# 🗂️ Setup logging per sekolah
log_dir = os.path.join("logs", "setup_tenant")
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, f"{db_name}.log")
logging.basicConfig(filename=log_file, level=logging.INFO)
log = logging.getLogger()

log.info(f"📦 Mulai setup tenant: {name}, DB: {db_name}, Jenjang: {jenjang}")

# 🔎 Cek CLI PostgreSQL di environment Laragon/Windows
def find_psql():
    possibles = [
        "C:\\Program Files\\PostgreSQL\\15\\bin\\psql.exe",  # adjust version
        "C:\\laragon\\bin\\postgresql\\pgsql\\bin\\psql.exe",  # Laragon default
        "psql"  # global CLI
    ]
    for path in possibles:
        if os.path.isfile(path) or path == "psql":
            return path
    return None

psql_path = find_psql()
if not psql_path:
    log.error("❌ PostgreSQL CLI tidak ditemukan")
    sys.exit(1)

# 🛠️ Buat database
try:
    log.info(f"🛠️ Membuat database '{db_name}' ...")
    subprocess.run([psql_path, "-U", "postgres", "-c", f"CREATE DATABASE {db_name};"], check=True)
    log.info(f"✅ Database '{db_name}' berhasil dibuat")
except subprocess.CalledProcessError as e:
    log.error(f"❌ Gagal membuat database: {str(e)}")
    sys.exit(1)

# 🌱 Seed awal (dummy, bisa kamu refactor)
try:
    log.info(f"🌱 Menambahkan seed data untuk jenjang '{jenjang}' ...")
    # tambahkan step import schema atau jalankan script seed jenjang
    log.info(f"✅ Seed data berhasil ditambahkan")
except Exception as e:
    log.error(f"❌ Gagal seed data: {str(e)}")

log.info("🧬 Setup tenant selesai\n")
